<?php
class dataface_actions_ajax_related_find_form {

	function handle(&$params){
		df_display(array(), 'xataface/RelatedList/forms/search_form.html');
		exit;

	}
	
}
