<?php
header('Location: installer.php');
exit;
