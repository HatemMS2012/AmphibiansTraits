<html>
<head>
<title><?php echo (isset($title) ? $title : 'Xataface Installer'); ?></title>
<script language="javascript" src="js/ajaxgold.js"></script>
<script language="javascript" src="install/install_form.js.php"></script>

<link rel="stylesheet" type="text/css" href="install/styles.css">

</head>
<body>
<div id="header-section">
	<h1><img src="logo-small.png" Alt="Xataface" height="40" align="top" /> Installer</h1>

</div>

<div id="main-section">
